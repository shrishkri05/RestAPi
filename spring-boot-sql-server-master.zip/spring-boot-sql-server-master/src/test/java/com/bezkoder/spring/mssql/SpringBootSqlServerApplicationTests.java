package com.bezkoder.spring.mssql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSqlServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
